package main

func main() {
  go helloWorld()
}

func helloWorld(){
  println("Hello World!")
}
