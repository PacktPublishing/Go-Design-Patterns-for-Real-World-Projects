package main

func main() {
  helloWorld()
}

func helloWorld(){
  println("Hello World!")
}
