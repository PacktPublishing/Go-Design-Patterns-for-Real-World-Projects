package abstract_factory

type Motorbike interface {
	GetType() int
}
