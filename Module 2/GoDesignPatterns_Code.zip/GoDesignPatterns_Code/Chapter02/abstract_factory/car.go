package abstract_factory

type Car interface {
	GetDoors() int
}
