package future

import (
	"errors"
	"testing"
	"sync"
)

func TestStringOrError_Execute(t *testing.T) {
	future := &MaybeString{}

	t.Run("Success result", func(t *testing.T) {

	})

	t.Run("Error result", func(t *testing.T) {

	})
}