package main

func main() {

}

func Multiply(a, b int) int {
	return a * b
}
