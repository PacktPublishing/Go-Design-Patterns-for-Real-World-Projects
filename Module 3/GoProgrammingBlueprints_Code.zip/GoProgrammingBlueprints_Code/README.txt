This book is aimed at developers seeking to learn application development and deployment
methods on Go.

The following chapters dont have code files, as there are no executable code present in the same:

Appendix.