// Package volt offers an API with functions to
// calculate voltage in a DC circuit using Ohm's law.
package volt
