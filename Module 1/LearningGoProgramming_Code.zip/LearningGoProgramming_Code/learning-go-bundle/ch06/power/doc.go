// Package power offers an API with functions
// to calculate electrical power in a DC circuit
package power
