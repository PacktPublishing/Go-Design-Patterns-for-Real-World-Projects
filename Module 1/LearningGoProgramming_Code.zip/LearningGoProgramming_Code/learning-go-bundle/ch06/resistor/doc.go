// Package resistor offers an API with functions
// to calculate resistance in an DC circuit using Ohm's law
package resistor
