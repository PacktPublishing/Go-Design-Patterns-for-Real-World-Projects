package resistor

// recip return reciprocal of a value val as 1/val.
func recip(val float64) float64 {
	return 1 / val
}
