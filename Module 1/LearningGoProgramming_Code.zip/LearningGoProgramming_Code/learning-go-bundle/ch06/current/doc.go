// Package current offers an api with functions
// to calculate current values in a DC circuit
// using Ohm's law
package current
