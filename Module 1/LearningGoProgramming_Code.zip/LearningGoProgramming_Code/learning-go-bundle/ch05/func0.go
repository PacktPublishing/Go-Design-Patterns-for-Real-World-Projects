package main

import (
	"fmt"
	"math"
)

func printPi() {
	fmt.Printf("printPi() %v\n", math.Pi)
}

func main() {
	printPi()
}
