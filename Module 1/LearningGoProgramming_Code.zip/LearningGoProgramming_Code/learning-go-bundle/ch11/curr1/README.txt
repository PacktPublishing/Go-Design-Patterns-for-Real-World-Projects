Package curr1
-------------
Manages currency data using json-tagged structs.
