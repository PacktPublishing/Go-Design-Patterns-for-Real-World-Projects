ISO 4217 Currency Code List
---------------------------
The currency data used in these examples is from the International Organization for Standardization (ISO).  
Downloaded from the ISO website at http://www.currency-iso.org/en/home/tables/table-a1.html.
