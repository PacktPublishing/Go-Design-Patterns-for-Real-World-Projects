package bazz

import (
	"fmt"
)

func Qux() {
	fmt.Println("bazz.Qux")
}
