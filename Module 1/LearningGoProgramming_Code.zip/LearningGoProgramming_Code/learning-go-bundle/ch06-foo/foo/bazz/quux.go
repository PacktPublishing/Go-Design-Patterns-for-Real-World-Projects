package bazz

import (
	"fmt"
)

func Quux() {
	Qux()
	fmt.Println("gazz.Quux")
}
