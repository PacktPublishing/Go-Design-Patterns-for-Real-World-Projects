package main

import "fmt"

func main() {
	currency := "US Dollar"
	country := "United States"
	code := "USD"
	fmt.Println("The currency of", country, "is the", currency, "(", code, ")")
}
