package main

import "fmt"

func main() {
	var readyToGo bool = false
	if !readyToGo {
		fmt.Println("Come on")
	} else {
		fmt.Println("Let's go!")
	}
}
