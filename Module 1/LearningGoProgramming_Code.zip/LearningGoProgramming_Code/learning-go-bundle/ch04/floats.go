package main

import "fmt"

func main() {
	p := 3.1415926535
	e := .5772156649
	x := 7.2E-5
	y := 1.616199e-35
	z := .416833e32

	fmt.Println(p, e, x, y, z)
}
