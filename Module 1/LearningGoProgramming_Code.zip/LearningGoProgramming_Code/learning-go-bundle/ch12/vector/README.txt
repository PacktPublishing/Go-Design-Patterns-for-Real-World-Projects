Package vector
--------------
Simple vector (math kind) implementation.
