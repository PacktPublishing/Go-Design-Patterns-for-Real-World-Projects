package main

import "fmt"

var steps int = 21
var msg = "Mastering Go in"

func main() {
	fmt.Println(msg, steps, "steps.")
}
