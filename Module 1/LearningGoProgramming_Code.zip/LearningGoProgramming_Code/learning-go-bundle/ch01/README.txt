To run examples:

go run <file-name>.go