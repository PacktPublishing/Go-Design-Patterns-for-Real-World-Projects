package main

import (
	"fmt"
	"reflect"
)

func main() {
	pi := 3.141592
	fmt.Println("type:", reflect.TypeOf(pi))
}
